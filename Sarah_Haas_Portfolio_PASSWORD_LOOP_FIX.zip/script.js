(function () {
  const buttons = document.querySelectorAll('[data-filter]');
  const items = document.querySelectorAll('[data-category]');

  buttons.forEach((button) => {
    button.addEventListener('click', () => {
      const filter = button.dataset.filter;
      buttons.forEach((item) => item.setAttribute('aria-pressed', 'false'));
      button.setAttribute('aria-pressed', 'true');
      items.forEach((item) => {
        item.style.display = filter === 'all' || item.dataset.category.includes(filter) ? '' : 'none';
      });
    });
  });

  const PASSWORD = 'portfolio'; // Placeholder password.
  const STORAGE_KEY = 'sarahPortfolioUnlocked';
  const overlay = document.querySelector('[data-password-overlay]');
  const unlocked = sessionStorage.getItem(STORAGE_KEY) === 'true';
  const isProtectedPage = document.body.classList.contains('protected-page');
  const pageName = (window.location.pathname.split('/').pop() || 'index.html').toLowerCase();
  const isPortfolioGate = pageName === 'work.html' || pageName === 'portfolio.html';

  // Protected case-study pages return to the portfolio gate only when locked.
  // Never redirect the portfolio gate to itself; that creates an endlessly growing ?next= URL.
  if (isProtectedPage && !isPortfolioGate && !overlay && !unlocked) {
    const current = pageName + window.location.search + window.location.hash;
    window.location.replace(`work.html?next=${encodeURIComponent(current)}`);
    return;
  }

  // A missing overlay on the gate should fail open rather than enter a redirect loop.
  if (!overlay) return;

  if (unlocked) {
    overlay.hidden = true;
    document.body.classList.remove('portfolio-locked');
    return;
  }

  overlay.hidden = false;
  document.body.classList.add('portfolio-locked');

  const form = overlay.querySelector('[data-password-form]');
  const input = overlay.querySelector('input[name="password"]');
  const error = overlay.querySelector('[data-password-error]');

  window.setTimeout(() => input && input.focus(), 50);

  form.addEventListener('submit', (event) => {
    event.preventDefault();

    if (input.value === PASSWORD) {
      sessionStorage.setItem(STORAGE_KEY, 'true');
      const next = new URLSearchParams(window.location.search).get('next');

      // Allow only a simple local HTML filename, with optional query/hash.
      if (next && /^[a-z0-9-]+\.html(?:[?#].*)?$/i.test(next) && !/^work\.html(?:[?#].*)?$/i.test(next)) {
        window.location.href = next;
        return;
      }

      // Remove an invalid or recursively nested query from the address bar.
      if (window.location.search) {
        window.history.replaceState({}, '', 'work.html');
      }

      overlay.hidden = true;
      document.body.classList.remove('portfolio-locked');
    } else {
      error.textContent = 'That password did not work. Please try again or contact Sarah.';
      input.select();
    }
  });
})();
