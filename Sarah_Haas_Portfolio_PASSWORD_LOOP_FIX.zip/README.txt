UPLOAD THESE THREE FILES TO THE ROOT OF YOUR GITHUB REPOSITORY AND REPLACE MATCHING FILES:

- index.html
- work.html
- script.js

Then wait 1–2 minutes and open a fresh private Safari tab at:
https://sarahehaas.github.io/

Portfolio placeholder password: portfolio
